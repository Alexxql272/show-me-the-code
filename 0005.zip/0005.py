from PIL import Image
import os
import re

WIDTH = 640
HEIGHT = 1136

base_path = 'C:/py4e/0005/source'

list = os.listdir(base_path)
# print(list)
for picture_name in list:
    picture_path = base_path + '/' + picture_name
    # print(picture_path)
    # print(picture_name[:-4]+'-副本')
    image = Image.open(picture_path)
    i_width, i_height = image.size
    # print(i_width, i_height)

    if i_width > WIDTH:
        print('图片:'+picture_name+'被修改')
        new_width = WIDTH
        new_height = int(WIDTH / i_width * i_height)
        out_image = image.resize((new_width, new_height),Image.ANTIALIAS)

        new_picture = picture_name[:-4] + '-副本' + picture_name[-4:]
        # print(new_picture)
        new_path = base_path + '/' + new_picture
        out_image.save(new_path)

    elif i_height > HEIGHT:
        print('图片:'+picture_name+'被修改')
        new_height = HEIGHT
        new_width = int(HEIGHT / i_height * i_width)
        out_image = image.resize((new_width, new_height),Image.ANTIALIAS)

        new_picture = picture_name[:-4] + '-副本' + picture_name[-4:]
        # print(new_picture)
        new_path = base_path + '/' + new_picture
        out_image.save(new_path)
