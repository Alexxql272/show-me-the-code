import os
import re

# 相对路径
base_path = 'source'
list = os.listdir(base_path)
# print(list)
# 遍历文件夹
for diary in list:
    path = base_path + '/' + diary
    hFile = open(path)
    # print(hFile)
    # text = hFile.read()
    # print(text)
    wordDict = dict()
    # 遍历文件
    for line in hFile:
        if len(line) < 1:
            continue
        # 正则表达式
        pieces = re.findall('[a-zA-Z]+', line)
        # 把词语录入词典
        for word in pieces:
            word = word.lower()
            wordDict[word] = wordDict.get(word, 1) + 1
    maxKey = None
    maxVal = None
    # 寻找最大值，限定key长于3为了排除介词
    for key, val in wordDict.items():
        if (maxVal == None or val > maxVal) and len(key) > 3:
            maxVal = val
            maxKey = key
    print(diary, maxKey, maxVal)
